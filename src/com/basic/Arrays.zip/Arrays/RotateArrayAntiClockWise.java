package com.basic.Arrays;

import java.util.Arrays;
import java.util.Scanner;

public class RotateArrayAntiClockWise {

	public static void main(String[] args) {

		int[] array = {1,2,3,4,5,6};
		Scanner sc =new Scanner(System.in);
		int rotations = sc.nextInt();
		System.out.println("The original array is : "+ Arrays.toString(array));
	    rotate(array,rotations);

	}

	private static void rotate(int[] array, int rotations) {
		
		
		
		
		
		
		
		
	}

}
