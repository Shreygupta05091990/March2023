package com.basic.Strings;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class FirstNonRepeatedCharacter {

	private static char firstNonRepeatedChar(String input_String) {

		Map<Character, Integer> FrequencyCountHashMap = new LinkedHashMap<Character, Integer>();
		for (int i = 0; i < input_String.length(); i++) {
			if (FrequencyCountHashMap.containsKey(input_String.charAt(i))) {

				FrequencyCountHashMap.put(input_String.charAt(i),
						FrequencyCountHashMap.get(input_String.charAt(i)) + 1);

			} else
				FrequencyCountHashMap.put(input_String.charAt(i), 1);

		}

		
		/***************Retrieval from HashMap***********************/
		for (Entry<Character, Integer>  entry: FrequencyCountHashMap.entrySet()) {
			
			if (entry.getValue()==1)
				return entry.getKey();
		}
		
		throw new RuntimeException("didn't find any non repeated character");
		
	}

	public static void main(String[] args) {

		String inputString = null;
		try {
		 inputString = "NAAAAAEEEFF";}
		catch(NullPointerException e) {
			e.printStackTrace();
			
		}
		char  non_repeated_character= firstNonRepeatedChar(inputString);
		
		System.out.println("The first non- repeated character--> " +non_repeated_character  );
	}

}
