package com.basic.Strings;

import java.util.Scanner;

public class WordsInString {

    public static int  countWordsInString(String string) {
    	String[] arr = string.split(" ");
		return arr.length;
    }
	
	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		String original_String=in.next();
		Integer count = countWordsInString(original_String);
		System.out.println("The words present in String are - " + count );
		
		
		

	}

}
