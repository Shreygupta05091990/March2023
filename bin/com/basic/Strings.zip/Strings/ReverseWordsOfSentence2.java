package com.basic.Strings;

import java.util.Scanner;

public class ReverseWordsOfSentence2 {
	
	
	
	public static void main(String[] args) {
		
		
		Scanner scn = new Scanner(System.in);
		String sentence = scn.nextLine();
//		String sentence = "Java  Interview Questions";
		String reversedSentence = reverseSentence(sentence);
		
		System.out.println(" The reversed sentence is --> " + reverseSentence(sentence));
		
	}

	private static String reverseSentence(String sentence) {
		String reverse = "";
		String[] words = sentence.split("\\s");  // String array gets created here of 3 elements .
		for (int i = words.length-1; i >=0	 ; i--) {
			reverse = reverse +words[i]+" ";
			
		}
		
		
		return reverse;
	}
	
	
	
	
	

}
