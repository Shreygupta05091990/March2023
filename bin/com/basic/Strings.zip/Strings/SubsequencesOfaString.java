package com.basic.Strings;

import java.util.Scanner;

public class SubsequencesOfaString {

	public static void main(String[] args) {
		
		Scanner scn = new Scanner(System.in); 
		String string= scn.next();
		
		func("",0,string.length(),string);
		
		

	}

	private static void func(StringBuilder string, int i, int length, String string2) {
    if (i==length) {
    	
    	System.out.println(string);
    }
    else {
    	func(string, i+1, length, string2);
    	string.append(string[i]);
    	
    }
		
	}

}
