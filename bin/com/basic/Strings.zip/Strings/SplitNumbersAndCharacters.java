package com.basic.Strings;

import java.util.Arrays;

public class SplitNumbersAndCharacters {
	
	
	
	
	public static void main(String[] args) {
		
		 
		
		 String str = "Shrey123";
	     splitString(str);
		
	}

	private static void splitString(String str) {
		
		
		StringBuffer num = new StringBuffer(), alpha = new StringBuffer(), special= new StringBuffer();
		for (int i=0; i<str.length(); i++)
        {
            if (Character.isDigit(str.charAt(i)))
                num.append(str.charAt(i));
            else if(Character.isAlphabetic(str.charAt(i)))
                alpha.append(str.charAt(i));
//            else
//                special.append(str.charAt(i));
        }
		
		char[] sortedString = sortString(alpha1);
		
		https://www.geeksforgeeks.org/split-numeric-alphabetic-and-special-symbols-from-a-string/
		
		

	}

	private static char[] sortString( String alpha1 ) {
       
		char[]  arr = alpha1.toCharArray();
		
		Arrays.sort(arr);
		
		return arr;
		
		
	}
}
