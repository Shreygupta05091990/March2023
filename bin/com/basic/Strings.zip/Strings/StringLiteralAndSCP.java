package com.basic.Strings;

public class StringLiteralAndSCP {

	public static void main(String[] args) {
		
		String s1= new String("Hello World");
		String s2= "Hello World";  //SCP 
		
		System.out.println(s1==s2);// False 
		
		if (s1.equals(s2)) {
			
			System.out.println("Content  of both is equal ");
		}
		

		
		String s3 = new 
		
	}

}
